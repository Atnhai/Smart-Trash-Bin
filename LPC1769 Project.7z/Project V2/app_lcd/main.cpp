// example to test the TFT Display
// Thanks to the GraphicsDisplay and TextDisplay classes
// test2.bmp has to be on the mbed file system
//Lib for 320*240 Pixel Color LCD with ILI9341 controller. Based on MI0283QT-9 datasheet

#include <stdio.h>
#include "mbed.h"
#include "SPI_TFT_ILI9341.h"
#include <string>
#include "Arial12x12.h"
#include "Arial24x23.h"
#include "Arial28x28.h"
#include "font_big.h"
#include "ultrasonic.h"

SPI_TFT_ILI9341 TFT(P0_18, P0_17, P0_15, P0_16, P0_10, P0_11,"TFT"); // mosi, miso, sclk, cs, reset, dc
DigitalOut LCD_LED(P0_2);

void dist(int distance)
{
	int space = ((207.0 - distance)/207.0) * 100.0;
	//put code here to happen when the distance is changed
	if(distance > 207){
		LCD_LED = 1; // backlight on
		TFT.claim(stdout);
		TFT.background(Black);
		TFT.foreground(White);
		TFT.set_orientation(1);
		TFT.set_font((unsigned char*) Arial24x23);
		TFT.locate(0,100);
		TFT.printf(" 0 %%");
	}

	else if(space > 75){
		LCD_LED = 1; // backlight on
		TFT.claim(stdout);
		TFT.background(Black);
		TFT.foreground(White);
		TFT.set_orientation(1);
		TFT.set_font((unsigned char*) Arial24x23);
		TFT.locate(0,100);
		TFT.printf("Full", space);
		}

	else{
		LCD_LED = 1; // backlight on
		TFT.claim(stdout);
		TFT.background(Black);
		TFT.foreground(White);
		TFT.set_orientation(1);
		TFT.set_font((unsigned char*) Arial24x23);
		TFT.locate(0,100);
		TFT.printf("%d %%", space);
	}

}

ultrasonic mu(P0_6, P0_0, .1, 1, &dist);    //Set the trigger pin to P0_6 and the echo pin to P0_0
                                        //have updates every .1 seconds and a timeout after 1
                                        //second, and call dist when the distance changes

int main()
{
    mu.startUpdates();//start measuring the distance
    while(1)
    {
        mu.checkDistance();     //call checkDistance() as much as possible, as this is where
                                //the class checks if dist needs to be called.
    }
}
